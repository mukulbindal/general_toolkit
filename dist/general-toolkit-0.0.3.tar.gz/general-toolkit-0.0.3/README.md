A genaral project aiming for cosnsolidating different functionalites under one global package.

Currently we support :
    AI 
    | ---- Document

 